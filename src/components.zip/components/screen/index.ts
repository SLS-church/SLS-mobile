import WebPageView from './WebPageView';
import QRCard from './QRCard';

export { WebPageView, QRCard };
